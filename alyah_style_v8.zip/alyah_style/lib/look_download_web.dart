import 'dart:html' as html;

String _escape(String value) => value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');

Future<void> downloadLookImageImpl({
  required String imageUrl,
  required String fileName,
}) async {
  final anchor = html.AnchorElement(href: imageUrl)
    ..download = fileName
    ..style.display = 'none';
  html.document.body?.children.add(anchor);
  anchor.click();
  anchor.remove();
}

Future<void> downloadLookPdfImpl({
  required String imageUrl,
  required String title,
  required String subtitle,
  required String stylistNote,
  required List<String> decisions,
  required String fileName,
}) async {
  final bullets = decisions
      .map((decision) => '<li>${_escape(decision)}</li>')
      .join('');
  final htmlContent = '''
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>${_escape(fileName)}</title>
  <style>
    body {
      margin: 0;
      background: #f7f1ea;
      color: #2e2723;
      font-family: Montserrat, Arial, sans-serif;
    }
    .page {
      width: 760px;
      margin: 0 auto;
      padding: 34px;
      background: #fffaf3;
    }
    .brand {
      text-align: center;
      letter-spacing: 2px;
      font-weight: 700;
      margin-bottom: 18px;
    }
    h1 {
      font-family: Georgia, serif;
      font-size: 34px;
      text-align: center;
      margin: 0 0 8px;
    }
    .subtitle {
      text-align: center;
      color: #776b61;
      margin-bottom: 24px;
    }
    img {
      width: 100%;
      border-radius: 18px;
      display: block;
      margin-bottom: 24px;
    }
    .note {
      background: #f1e7dc;
      border-radius: 16px;
      padding: 20px;
      line-height: 1.55;
      margin-bottom: 18px;
    }
    h2 {
      font-size: 16px;
      margin: 0 0 8px;
    }
    li {
      margin-bottom: 8px;
      line-height: 1.4;
    }
    .disclaimer {
      color: #776b61;
      font-size: 12px;
      margin-top: 18px;
    }
    @media print {
      body { background: #fff; }
      .page { width: auto; padding: 24px; }
    }
  </style>
</head>
<body>
  <main class="page">
    <div class="brand">ALYAH</div>
    <h1>${_escape(title)}</h1>
    <div class="subtitle">${_escape(subtitle)}</div>
    <img src="${_escape(imageUrl)}" alt="Alyah curated look">
    <section class="note">
      <h2>Alyah Stylist Note</h2>
      <div>${_escape(stylistNote)}</div>
    </section>
    <section>
      <h2>Styling Decisions</h2>
      <ul>$bullets</ul>
    </section>
    <div class="disclaimer">
      Visual styling direction. Fit, prices and real availability need to be checked when shopping.
    </div>
  </main>
  <script>
    window.onload = () => setTimeout(() => window.print(), 300);
  </script>
</body>
</html>
''';
  final blob = html.Blob([htmlContent], 'text/html');
  final url = html.Url.createObjectUrlFromBlob(blob);
  html.window.open(url, '_blank');
  Future<void>.delayed(const Duration(seconds: 10), () {
    html.Url.revokeObjectUrl(url);
  });
}
