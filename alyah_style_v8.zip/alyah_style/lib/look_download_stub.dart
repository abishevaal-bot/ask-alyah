Future<void> downloadLookImageImpl({
  required String imageUrl,
  required String fileName,
}) async {}

Future<void> downloadLookPdfImpl({
  required String imageUrl,
  required String title,
  required String subtitle,
  required String stylistNote,
  required List<String> decisions,
  required String fileName,
}) async {}
