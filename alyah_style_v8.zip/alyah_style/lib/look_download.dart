import 'look_download_stub.dart'
    if (dart.library.html) 'look_download_web.dart';

Future<void> downloadLookImage({
  required String imageUrl,
  String fileName = 'alyah-look.jpg',
}) =>
    downloadLookImageImpl(imageUrl: imageUrl, fileName: fileName);

Future<void> downloadLookPdf({
  required String imageUrl,
  required String title,
  required String subtitle,
  required String stylistNote,
  required List<String> decisions,
  String fileName = 'alyah-styling-card.pdf',
}) =>
    downloadLookPdfImpl(
      imageUrl: imageUrl,
      title: title,
      subtitle: subtitle,
      stylistNote: stylistNote,
      decisions: decisions,
      fileName: fileName,
    );
