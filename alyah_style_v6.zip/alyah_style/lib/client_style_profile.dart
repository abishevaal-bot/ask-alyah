class ClientStyleProfile {
  ClientStyleProfile._();
  static final ClientStyleProfile instance = ClientStyleProfile._();

  String bodyShape = '';
  String heightCategory = '';
  String size = '';
  String skinTone = '';
  String hairColor = '';
  List<String> desiredFeel = [];
  List<String> styleDirections = [];
  String mainGoal = '';

  String get kibbeGuidance {
    final shape = bodyShape.isEmpty ? 'unspecified body shape' : bodyShape;
    final height = heightCategory.isEmpty ? 'unspecified vertical line' : heightCategory;
    return 'Use Kibbe-informed styling principles appropriate to a $shape shape and $height vertical line. Do not invent a formal Kibbe type; use the supplied proportions to choose flattering line, scale, structure, drape and garment length.';
  }

  String get promptSummary => '''
CLIENT PROFILE (must visibly influence the result):
- Body shape: ${bodyShape.isEmpty ? 'not specified' : bodyShape}
- Height/proportion category: ${heightCategory.isEmpty ? 'not specified' : heightCategory}
- Clothing size: ${size.isEmpty ? 'not specified' : size}${heightCategory == 'Petite' ? ' Petite' : ''}
- Skin tone: ${skinTone.isEmpty ? 'not specified' : skinTone}
- Hair color: ${hairColor.isEmpty ? 'not specified' : hairColor}
- Desired feeling: ${desiredFeel.isEmpty ? 'not specified' : desiredFeel.join(', ')}
- Style direction: ${styleDirections.isEmpty ? 'not specified' : styleDirections.join(', ')}
- Main styling goal: ${mainGoal.isEmpty ? 'not specified' : mainGoal}
$kibbeGuidance
''';
}
