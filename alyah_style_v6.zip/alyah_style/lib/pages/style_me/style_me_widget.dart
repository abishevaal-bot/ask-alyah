import '/backend/api_requests/api_calls.dart';
import '/components/section_header2/section_header2_widget.dart';
import '/components/text_field/text_field_widget.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/index.dart';
import '/client_style_profile.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'style_me_model.dart';
export 'style_me_model.dart';

class StyleMeWidget extends StatefulWidget {
  const StyleMeWidget({super.key});

  static String routeName = 'StyleMe';
  static String routePath = '/styleMe';

  @override
  State<StyleMeWidget> createState() => _StyleMeWidgetState();
}

class _StyleMeWidgetState extends State<StyleMeWidget> {
  late StyleMeModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();
  final _occasionDetailsController = TextEditingController();
  final _preferencesController = TextEditingController();
  final _avoidController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => StyleMeModel());
  }

  @override
  void dispose() {
    _model.dispose();
    _occasionDetailsController.dispose();
    _preferencesController.dispose();
    _avoidController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: Color(0xFFFFFBF5),
        body: SingleChildScrollView(
          primary: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: EdgeInsets.all(24.0),
                child: Container(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          FlutterFlowIconButton(
                            borderRadius: 8.0,
                            buttonSize: 40.0,
                            fillColor: Colors.transparent,
                            icon: Icon(
                              Icons.arrow_back_ios_new_rounded,
                              color: FlutterFlowTheme.of(context).primaryText,
                              size: 20.0,
                            ),
                            onPressed: () async {
                              context.safePop();
                            },
                          ),
                          Text(
                            'Style Me',
                            style: FlutterFlowTheme.of(context)
                                .titleLarge
                                .override(
                                  font: GoogleFonts.playfairDisplay(
                                    fontWeight: FontWeight.bold,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .titleLarge
                                        .fontStyle,
                                  ),
                                  color:
                                      FlutterFlowTheme.of(context).primaryText,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .titleLarge
                                      .fontStyle,
                                  lineHeight: 1.3,
                                ),
                          ),
                          Container(
                            width: 40.0,
                          ),
                        ],
                      ),
                      Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            width: 40.0,
                            height: 4.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context).primary,
                              borderRadius: BorderRadius.circular(9999.0),
                              shape: BoxShape.rectangle,
                            ),
                          ),
                          Container(
                            width: 40.0,
                            height: 4.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context).primary,
                              borderRadius: BorderRadius.circular(9999.0),
                              shape: BoxShape.rectangle,
                            ),
                          ),
                          Container(
                            width: 40.0,
                            height: 4.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context).primary,
                              borderRadius: BorderRadius.circular(9999.0),
                              shape: BoxShape.rectangle,
                            ),
                          ),
                          Container(
                            width: 40.0,
                            height: 4.0,
                            decoration: BoxDecoration(
                              color: FlutterFlowTheme.of(context).primary,
                              borderRadius: BorderRadius.circular(9999.0),
                              shape: BoxShape.rectangle,
                            ),
                          ),
                        ].divide(SizedBox(width: 8.0)),
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'What\'s the occasion?',
                            style: FlutterFlowTheme.of(context)
                                .headlineMedium
                                .override(
                                  font: GoogleFonts.playfairDisplay(
                                    fontWeight: FontWeight.bold,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .headlineMedium
                                        .fontStyle,
                                  ),
                                  color:
                                      FlutterFlowTheme.of(context).primaryText,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .headlineMedium
                                      .fontStyle,
                                  lineHeight: 1.25,
                                ),
                          ),
                          Text(
                            'Tell Alyah what you\'re dressing for, and she\'ll curate the perfect look based on your Style Identity.',
                            style:
                                FlutterFlowTheme.of(context).bodyLarge.override(
                                      font: GoogleFonts.montserrat(
                                        fontWeight: FlutterFlowTheme.of(context)
                                            .bodyLarge
                                            .fontWeight,
                                        fontStyle: FlutterFlowTheme.of(context)
                                            .bodyLarge
                                            .fontStyle,
                                      ),
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryText,
                                      letterSpacing: 0.0,
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .bodyLarge
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .bodyLarge
                                          .fontStyle,
                                      lineHeight: 1.5,
                                    ),
                          ),
                        ].divide(SizedBox(height: 8.0)),
                      ),
                      FlutterFlowChoiceChips(
                        options: [
                          ChipData('Everyday'),
                          ChipData('Work'),
                          ChipData('Date Night'),
                          ChipData('Dinner'),
                          ChipData('Wedding'),
                          ChipData('Event'),
                          ChipData('Travel')
                        ],
                        onChanged: (val) => safeSetState(
                            () => _model.choiceChipsValue1 = val?.firstOrNull),
                        selectedChipStyle: ChipStyle(
                          backgroundColor: FlutterFlowTheme.of(context).primary,
                          textStyle:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    font: GoogleFonts.montserrat(
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontStyle,
                                    ),
                                    color: FlutterFlowTheme.of(context).info,
                                    letterSpacing: 0.0,
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontStyle,
                                  ),
                          iconColor: FlutterFlowTheme.of(context).info,
                          iconSize: 16.0,
                          elevation: 0.0,
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        unselectedChipStyle: ChipStyle(
                          backgroundColor:
                              FlutterFlowTheme.of(context).secondaryBackground,
                          textStyle: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .override(
                                font: GoogleFonts.montserrat(
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .fontStyle,
                                ),
                                color:
                                    FlutterFlowTheme.of(context).secondaryText,
                                letterSpacing: 0.0,
                                fontWeight: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .fontWeight,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .fontStyle,
                              ),
                          iconColor: FlutterFlowTheme.of(context).secondaryText,
                          iconSize: 16.0,
                          elevation: 0.0,
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        chipSpacing: 8.0,
                        rowSpacing: 8.0,
                        multiselect: false,
                        alignment: WrapAlignment.start,
                        controller: _model.choiceChipsValueController1 ??=
                            FormFieldController<List<String>>(
                          [],
                        ),
                        wrapped: true,
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          wrapWithModel(
                            model: _model.sectionHeaderModel1,
                            updateCallback: () => safeSetState(() {}),
                            child: SectionHeader2Widget(
                              subtitle: 'When are you wearing this?',
                              title: 'Occasion',
                            ),
                          ),
                        ],
                      ),
                      _alyahInput(
                        controller: _occasionDetailsController,
                        label: 'Tell Alyah more about the occasion (optional)',
                        hint: 'e.g. Outdoor wedding in Napa in October, cocktail attire, ceremony at 4 PM, mostly on grass',
                        maxLines: 3,
                      ),
                      _alyahInput(
                        controller: _preferencesController,
                        label: 'What would you love to see?',
                        hint: 'e.g. I love burgundy and navy, feminine silhouettes, interesting tailoring',
                        maxLines: 3,
                      ),
                      _alyahInput(
                        controller: _avoidController,
                        label: 'Anything to avoid?',
                        hint: 'e.g. No beige, no mini skirts, no high heels, no sleeveless tops',
                        maxLines: 3,
                      ),
                      FlutterFlowChoiceChips(
                        options: [
                          ChipData('\$ Budget Friendly'),
                          ChipData('\$\$ Mid-Range'),
                          ChipData('\$\$\$ Investment')
                        ],
                        onChanged: (val) => safeSetState(
                            () => _model.choiceChipsValue2 = val?.firstOrNull),
                        selectedChipStyle: ChipStyle(
                          backgroundColor: FlutterFlowTheme.of(context).primary,
                          textStyle:
                              FlutterFlowTheme.of(context).bodyMedium.override(
                                    font: GoogleFonts.montserrat(
                                      fontWeight: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontWeight,
                                      fontStyle: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .fontStyle,
                                    ),
                                    color: FlutterFlowTheme.of(context).info,
                                    letterSpacing: 0.0,
                                    fontWeight: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontWeight,
                                    fontStyle: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .fontStyle,
                                  ),
                          iconColor: FlutterFlowTheme.of(context).info,
                          iconSize: 16.0,
                          elevation: 0.0,
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        unselectedChipStyle: ChipStyle(
                          backgroundColor:
                              FlutterFlowTheme.of(context).secondaryBackground,
                          textStyle: FlutterFlowTheme.of(context)
                              .bodyMedium
                              .override(
                                font: GoogleFonts.montserrat(
                                  fontWeight: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .fontWeight,
                                  fontStyle: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .fontStyle,
                                ),
                                color:
                                    FlutterFlowTheme.of(context).secondaryText,
                                letterSpacing: 0.0,
                                fontWeight: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .fontWeight,
                                fontStyle: FlutterFlowTheme.of(context)
                                    .bodyMedium
                                    .fontStyle,
                              ),
                          iconColor: FlutterFlowTheme.of(context).secondaryText,
                          iconSize: 16.0,
                          elevation: 0.0,
                          borderRadius: BorderRadius.circular(8.0),
                        ),
                        chipSpacing: 8.0,
                        rowSpacing: 8.0,
                        multiselect: false,
                        alignment: WrapAlignment.start,
                        controller: _model.choiceChipsValueController2 ??=
                            FormFieldController<List<String>>(
                          [],
                        ),
                        wrapped: true,
                      ),
                      Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          wrapWithModel(
                            model: _model.sectionHeaderModel2,
                            updateCallback: () => safeSetState(() {}),
                            child: SectionHeader2Widget(
                              subtitle: 'Keep your style goals realistic',
                              title: 'Budget Preference',
                            ),
                          ),
                        ],
                      ),
                      Container(
                        width: double.infinity,
                        padding: EdgeInsets.all(16.0),
                        decoration: BoxDecoration(
                          color: Color(0xFFF5F0EA),
                          borderRadius: BorderRadius.circular(16.0),
                        ),
                        child: Text(
                          'Alyah will create a polished look using your occasion and budget.',
                          style: FlutterFlowTheme.of(context).bodyMedium.override(
                                font: GoogleFonts.montserrat(),
                                color: FlutterFlowTheme.of(context).secondaryText,
                                letterSpacing: 0.0,
                              ),
                        ),
                      ),
                      Container(
                        height: 24.0,
                      ),
                      InkWell(
                        splashColor: Colors.transparent,
                        focusColor: Colors.transparent,
                        hoverColor: Colors.transparent,
                        highlightColor: Colors.transparent,
                        onTap: () async {
                          final occasion = _model.choiceChipsValue1 ?? 'Everyday';
                          final budget = _model.choiceChipsValue2 ?? r'$$ Mid-Range';
                          final profile = ClientStyleProfile.instance;
                          final occasionDetails = _occasionDetailsController.text.trim();
                          final preferences = _preferencesController.text.trim();
                          final avoid = _avoidController.text.trim();
                          final occasionRule = (occasion == 'Dinner' || occasion == 'Event')
                              ? 'This is a special occasion. Make the styling clearly elevated, polished, distinctive and event-worthy — not a basic daytime outfit. Use refined fabrics, intentional accessories and sophisticated footwear.'
                              : 'Make the styling clearly appropriate to the stated occasion.';
                          final prompt = '''
Act as Alyah, an expert women's personal stylist. Create ONE complete, realistic head-to-toe outfit for this specific client.
${profile.promptSummary}
STYLING REQUEST:
- Occasion: $occasion
- Budget: $budget
- Occasion details: ${occasionDetails.isEmpty ? 'not specified' : occasionDetails}
- Client preferences: ${preferences.isEmpty ? 'not specified' : preferences}
- Hard restrictions / avoid: ${avoid.isEmpty ? 'none specified' : avoid}
$occasionRule

PRIORITY RULES:
1. Never violate the client's hard restrictions.
2. Respect venue, dress code, season, weather, time of day and practical details supplied by the client.
3. Style for the client's proportions, size, coloring and Style Identity.
4. Honor preferences without making every look repetitive.
5. Budget controls price level, NOT creativity or sophistication.

PERSONALIZATION RULES:
Respect the client's actual size and proportions. If Petite is selected, show a genuinely petite-scale adult woman and use petite-friendly garment proportions, intentional waist placement, appropriate hem lengths and accessories scaled to her frame. Do not depict an average/large frame when XS/S Petite is specified.
Keep visible characteristics consistent: hair must be ${profile.hairColor.isEmpty ? 'natural and harmonious with the client profile' : profile.hairColor}; choose clothing colors that harmonize with ${profile.skinTone.isEmpty ? 'the client skin tone' : profile.skinTone + ' skin'}.
Use the body shape and Kibbe-informed guidance to choose silhouette, structure, drape, vertical line, neckline and lengths. Do not change the client's body to fit the clothes; style the clothes for the client.
Honor the selected style goals while keeping the result modern, feminine, sophisticated and wearable.
Do NOT default to beige, cream, camel or brown. Build a deliberate palette from the client's skin tone, hair color, contrast, preferences and occasion. Neutrals are allowed only when they genuinely serve the client.
The result must feel curated by a professional stylist, not like a generic Pinterest outfit. Include at least 2-3 intentional styling decisions through silhouette, color, texture, layering, accessories or proportion.
For Wedding or Event, make the look clearly special-occasion appropriate. For outdoor settings, account for ground surface, weather and practical footwear. For Travel, prioritize comfort, layering and practicality without losing style.

IMAGE RULES:
Show one adult woman wearing the entire coordinated outfit from head to toe, including shoes, handbag and tasteful jewelry/accessories. Clean neutral editorial background, realistic fashion photography, natural anatomy and proportions.
Generate ONE cohesive fashion look only. No collage, product grid, flat lay, separate product photos, text, labels, logos, random objects, food, animals, wine corks, unrelated accessories, menswear or men.
''';

                          _model.generatedLook =
                              await GeneratedAlyahLookCall.call(prompt: prompt);

                          final imageUrl = GeneratedAlyahLookCall.imageUrl(
                            _model.generatedLook?.jsonBody,
                          );

                          if ((_model.generatedLook?.succeeded ?? false) &&
                              imageUrl != null &&
                              imageUrl.isNotEmpty) {
                            context.pushNamed(
                              MyLookWidget.routeName,
                              queryParameters: {
                                'generatedImage': serializeParam(
                                  imageUrl,
                                  ParamType.String,
                                ),
                                'occasion': serializeParam(
                                  occasion,
                                  ParamType.String,
                                ),
                                'budget': serializeParam(
                                  budget,
                                  ParamType.String,
                                ),
                              }.withoutNulls,
                            );
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                  'Alyah could not create your look yet. Please try again.',
                                ),
                              ),
                            );
                          }

                          safeSetState(() {});
                        },
                        child: Container(
                          width: double.infinity,
                          constraints: BoxConstraints(minHeight: 58.0),
                          decoration: BoxDecoration(
                            color: Color(0xFF4A3728),
                            borderRadius: BorderRadius.circular(24.0),
                            shape: BoxShape.rectangle,
                          ),
                          child: Padding(
                            padding: EdgeInsets.all(20.0),
                            child: Container(
                              alignment: AlignmentDirectional(0.0, 0.0),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.auto_fix_high_rounded,
                                    color: Color(0xFFFDF6E3),
                                    size: 20.0,
                                  ),
                                  Text(
                                    'Create My Look',
                                    style: FlutterFlowTheme.of(context)
                                        .titleMedium
                                        .override(
                                          font: GoogleFonts.montserrat(
                                            fontWeight: FontWeight.w600,
                                            fontStyle: FlutterFlowTheme.of(context)
                                                .titleMedium
                                                .fontStyle,
                                          ),
                                          color: Color(0xFFFDF6E3),
                                          letterSpacing: 0.0,
                                          fontWeight: FontWeight.w600,
                                          fontStyle: FlutterFlowTheme.of(context)
                                              .titleMedium
                                              .fontStyle,
                                          lineHeight: 1.4,
                                        ),
                                  ),
                                ].divide(SizedBox(width: 16.0)),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ].divide(SizedBox(height: 32.0)),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _alyahInput({
    required TextEditingController controller,
    required String label,
    required String hint,
    int maxLines = 2,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          label,
          style: FlutterFlowTheme.of(context).labelLarge.override(
                font: GoogleFonts.montserrat(fontWeight: FontWeight.w600),
                fontWeight: FontWeight.w600,
              ),
        ),
        const SizedBox(height: 8.0),
        TextField(
          controller: controller,
          maxLines: maxLines,
          decoration: InputDecoration(
            hintText: hint,
            hintStyle: FlutterFlowTheme.of(context).bodyMedium.override(
                  font: GoogleFonts.montserrat(),
                  color: FlutterFlowTheme.of(context).secondaryText,
                ),
            filled: true,
            fillColor: FlutterFlowTheme.of(context).secondaryBackground,
            contentPadding: const EdgeInsets.all(16.0),
            enabledBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Color(0xFFE4DDD5)),
              borderRadius: BorderRadius.circular(14.0),
            ),
            focusedBorder: OutlineInputBorder(
              borderSide: const BorderSide(color: Color(0xFF4A3728), width: 1.4),
              borderRadius: BorderRadius.circular(14.0),
            ),
          ),
          style: FlutterFlowTheme.of(context).bodyMedium.override(
                font: GoogleFonts.montserrat(),
              ),
        ),
      ],
    );
  }

}

