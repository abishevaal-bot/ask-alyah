import 'package:flutter/material.dart';
import '/look_history.dart';
import '/look_image.dart';
import '/pages/my_look/my_look_widget.dart';

class MyLooksWidget extends StatefulWidget {
  const MyLooksWidget({super.key});
  @override
  State<MyLooksWidget> createState() => _MyLooksWidgetState();
}

class _MyLooksWidgetState extends State<MyLooksWidget> {
  late Future<List<Map<String, dynamic>>> _looks;
  @override
  void initState() {
    super.initState();
    _looks = LookHistory.load();
  }

  void _reload() => setState(() {
        _looks = LookHistory.load();
      });

  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: const Color(0xFFFFFBF5),
        appBar: AppBar(
            title: const Text('My Looks / History'),
            backgroundColor: const Color(0xFFFFFBF5)),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: _looks,
          builder: (context, snapshot) {
            if (snapshot.hasError)
              return Center(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Text('Your history could not be loaded.'),
                TextButton(onPressed: _reload, child: const Text('Try again')),
              ]));
            if (!snapshot.hasData)
              return const Center(child: CircularProgressIndicator());
            final looks = snapshot.data!;
            return ListView(padding: const EdgeInsets.all(20), children: [
              const Text(
                  'Saved on this device. Clearing app or browser data removes this history.'),
              const SizedBox(height: 16),
              if (looks.isEmpty)
                const Padding(
                    padding: EdgeInsets.all(32),
                    child: Text('Your saved looks will appear here.')),
              for (final look in looks)
                Card(
                    child: Column(children: [
                  InkWell(
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => MyLookWidget(
                        generatedImage: look['imageUrl'] as String,
                        occasion: (look['requestSnapshot'] as Map?)?['occasion']
                            as String?,
                        budget: (look['requestSnapshot'] as Map?)?['budget']
                            as String?,
                        lookData: look,
                        initiallySaved: true,
                      ),
                    )),
                    child: Column(children: [
                      lookImage(look['imageUrl'] as String, height: 280),
                      ListTile(
                          title: Text(
                              (look['plan'] as Map?)?['concept'] as String? ??
                                  'Saved look'),
                          subtitle: Text((look['createdAt'] as String? ?? '')
                              .split('T')
                              .first)),
                    ]),
                  ),
                  TextButton.icon(
                      onPressed: () async {
                        final remove = await showDialog<bool>(
                            context: context,
                            builder: (context) => AlertDialog(
                                    title:
                                        const Text('Delete this saved look?'),
                                    actions: [
                                      TextButton(
                                          onPressed: () =>
                                              Navigator.pop(context, false),
                                          child: const Text('Keep')),
                                      TextButton(
                                          onPressed: () =>
                                              Navigator.pop(context, true),
                                          child: const Text('Delete')),
                                    ]));
                        if (remove != true) return;
                        try {
                          await LookHistory.delete(look['id'] as String);
                          if (mounted) _reload();
                        } catch (_) {
                          if (mounted)
                            ScaffoldMessenger.of(context).showSnackBar(
                                const SnackBar(
                                    content:
                                        Text('Could not delete this look.')));
                        }
                      },
                      icon: const Icon(Icons.delete_outline),
                      label: const Text('Delete')),
                ])),
            ]);
          },
        ),
      );
}
