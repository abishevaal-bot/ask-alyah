import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '/look_history.dart';
import '/look_image.dart';
import '/pages/my_looks/my_looks_widget.dart';

class MyLookWidget extends StatefulWidget {
  const MyLookWidget({
    super.key,
    required this.generatedImage,
    this.occasion,
    this.budget,
    this.lookData,
    this.initiallySaved = false,
  });

  final String? generatedImage;
  final String? occasion;
  final String? budget;
  final Map<String, dynamic>? lookData;
  final bool initiallySaved;

  static String routeName = 'MyLook';
  static String routePath = '/myLook';

  @override
  State<MyLookWidget> createState() => _MyLookWidgetState();
}

class _MyLookWidgetState extends State<MyLookWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();
  bool _saving = false;
  late bool _saved;

  @override
  void initState() {
    super.initState();
    _saved = widget.initiallySaved;
  }

  Future<void> _save() async {
    if (_saving || _saved || widget.lookData == null) return;
    setState(() => _saving = true);
    try {
      await LookHistory.save(widget.lookData!);
      if (mounted) setState(() => _saved = true);
    } catch (error) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text(error is StateError
                ? error.message.toString()
                : 'Could not save this look. Please try again.')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final occasion = (widget.occasion?.isNotEmpty ?? false)
        ? widget.occasion!
        : 'your occasion';
    final budget =
        (widget.budget?.isNotEmpty ?? false) ? widget.budget! : 'your budget';

    return Scaffold(
      key: scaffoldKey,
      backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 760.0),
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20.0, 12.0, 20.0, 36.0),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        FlutterFlowIconButton(
                          borderRadius: 8.0,
                          buttonSize: 40.0,
                          fillColor: Colors.transparent,
                          icon: Icon(Icons.arrow_back_ios_new_rounded,
                              color: FlutterFlowTheme.of(context).primaryText,
                              size: 20.0),
                          onPressed: () {
                            if (widget.initiallySaved) {
                              Navigator.of(context).pop();
                            } else {
                              context.goNamed(StyleMeWidget.routeName);
                            }
                          },
                        ),
                        Text(
                          'ALYAH',
                          style:
                              FlutterFlowTheme.of(context).titleMedium.override(
                                    font: GoogleFonts.montserrat(
                                        fontWeight: FontWeight.bold),
                                    letterSpacing: 1.2,
                                    fontWeight: FontWeight.bold,
                                  ),
                        ),
                        const SizedBox(width: 40.0),
                      ],
                    ),
                    const SizedBox(height: 22.0),
                    Text(
                      'Your Curated Look',
                      textAlign: TextAlign.center,
                      style:
                          FlutterFlowTheme.of(context).headlineMedium.override(
                                font: GoogleFonts.playfairDisplay(
                                    fontWeight: FontWeight.w600),
                                fontWeight: FontWeight.w600,
                              ),
                    ),
                    const SizedBox(height: 8.0),
                    Text(
                      '$occasion • $budget',
                      textAlign: TextAlign.center,
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            font: GoogleFonts.montserrat(),
                            color: FlutterFlowTheme.of(context).secondaryText,
                          ),
                    ),
                    const SizedBox(height: 24.0),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(20.0),
                      child: (widget.generatedImage?.isNotEmpty ?? false)
                          ? lookImage(widget.generatedImage!)
                          : _messageCard(context,
                              'Alyah did not receive an image. Please create the look again.'),
                    ),
                    const SizedBox(height: 24.0),
                    Container(
                      padding: const EdgeInsets.all(20.0),
                      decoration: BoxDecoration(
                        color: const Color(0xFFF5F0EA),
                        borderRadius: BorderRadius.circular(16.0),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Icon(Icons.auto_awesome_rounded,
                              color: FlutterFlowTheme.of(context).primary,
                              size: 22.0),
                          const SizedBox(width: 12.0),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Text('Alyah Stylist Note',
                                    style: FlutterFlowTheme.of(context)
                                        .labelLarge
                                        .override(
                                          font: GoogleFonts.montserrat(
                                              fontWeight: FontWeight.bold),
                                          fontWeight: FontWeight.bold,
                                        )),
                                const SizedBox(height: 6.0),
                                Text(
                                  (widget.lookData?['plan']
                                          as Map?)?['rationale'] as String? ??
                                      'Your personal styling explanation will appear here.',
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                          font: GoogleFonts.montserrat(),
                                          lineHeight: 1.5),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 20.0),
                    if (widget.lookData != null) ...[
                      for (final decision in ((widget.lookData?['plan']
                              as Map?)?['stylingDecisions'] as List? ??
                          []))
                        Padding(
                            padding: const EdgeInsets.only(bottom: 8),
                            child: Text('• $decision')),
                      const Text(
                          'Visual styling direction. Fit and prices need to be checked when shopping.'),
                      const SizedBox(height: 16),
                      ElevatedButton.icon(
                        onPressed: _saved || _saving ? null : _save,
                        icon: Icon(
                            _saved ? Icons.check : Icons.bookmark_add_outlined),
                        label: Text(_saving
                            ? 'Saving…'
                            : _saved
                                ? 'Saved to History'
                                : 'Save to History'),
                      ),
                      const Text('Saved on this device.',
                          textAlign: TextAlign.center),
                    ],
                    TextButton.icon(
                      onPressed: () => Navigator.of(context).push(
                          MaterialPageRoute(
                              builder: (_) => const MyLooksWidget())),
                      icon: const Icon(Icons.history),
                      label: const Text('My Looks / History'),
                    ),
                    SizedBox(
                      height: 54.0,
                      child: ElevatedButton.icon(
                        onPressed: () =>
                            context.goNamed(StyleMeWidget.routeName),
                        icon: const Icon(Icons.refresh_rounded),
                        label: const Text('Create Another Look'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF4A3728),
                          foregroundColor: const Color(0xFFFDF6E3),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18.0)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _messageCard(BuildContext context, String text) => Container(
        width: double.infinity,
        constraints: const BoxConstraints(minHeight: 220.0),
        color: const Color(0xFFF5F0EA),
        alignment: Alignment.center,
        padding: const EdgeInsets.all(24.0),
        child: Text(text,
            textAlign: TextAlign.center,
            style: FlutterFlowTheme.of(context).bodyMedium),
      );
}
