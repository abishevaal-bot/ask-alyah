import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Local history contains the original request, profile, plan and durable image.
/// It is device/browser specific until account synchronization is implemented.
class LookHistory {
  static const _key = 'alyah_looks_v7';
  static const _maxBytes = 20 * 1024 * 1024;
  static Future<List<Map<String, dynamic>>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key);
    if (raw == null) return [];
    // Do not silently discard an unreadable history and overwrite it.
    final values = jsonDecode(raw) as List;
    return values.map((v) => Map<String, dynamic>.from(v as Map)).toList();
  }

  static Future<void> save(Map<String, dynamic> look) async {
    if (look['status'] != 'complete' ||
        look['id'] is! String ||
        look['imageUrl'] is! String ||
        (look['imageUrl'] as String).isEmpty) {
      throw const FormatException('Incomplete look');
    }
    final looks = await load();
    if (looks.any((v) => v['id'] == look['id'])) return;
    final encoded = jsonEncode([look, ...looks]);
    if (utf8.encode(encoded).length > _maxBytes) {
      throw StateError('History is full. Delete an older look before saving.');
    }
    final prefs = await SharedPreferences.getInstance();
    if (!await prefs.setString(_key, encoded)) {
      throw StateError('Could not save this look. Please try again.');
    }
  }

  static Future<void> delete(String id) async {
    final looks = await load();
    looks.removeWhere((v) => v['id'] == id);
    final prefs = await SharedPreferences.getInstance();
    if (!await prefs.setString(_key, jsonEncode(looks))) {
      throw StateError('Could not delete this look.');
    }
  }
}
