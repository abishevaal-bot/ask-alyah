import 'dart:convert';
import 'package:flutter/material.dart';

Widget lookImage(String source, {double? height, BoxFit fit = BoxFit.contain}) {
  Widget failure(BuildContext context, Object error, StackTrace? trace) =>
      const SizedBox(
          height: 180, child: Center(child: Text('Image unavailable.')));
  if (source.startsWith('data:image/')) {
    try {
      return Image.memory(base64Decode(source.split(',').last),
          height: height,
          width: double.infinity,
          fit: fit,
          errorBuilder: failure);
    } catch (_) {
      return const SizedBox(
          height: 180, child: Center(child: Text('Image unavailable.')));
    }
  }
  return Image.network(source,
      height: height, width: double.infinity, fit: fit, errorBuilder: failure);
}
