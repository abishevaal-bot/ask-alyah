import {test} from "node:test";
import assert from "node:assert/strict";
import worker, {normalizeInput, validatePlan, validateReview, createLook, imagePrompt} from "../src/index.js";

const input = normalizeInput({version: 7,
  profile: {bodyShape: "Pear", heightCategory: "Petite", size: "XS", skinTone: "Light", hairColor: "Dark brown",
    desiredFeel: ["Confident"], styleDirections: ["Modern"], mainGoal: "Balance proportions"},
  request: {occasion: "Wedding", budget: "$ Budget Friendly",
    occasionDetails: "Outdoor wedding on grass", preferences: "Burgundy, interesting tailoring", avoid: "No beige, no high heels, no sleeveless"}});
const plan = () => ({
  concept: "Sculptural burgundy for an outdoor wedding",
  clientAnalysis: {proportions: "Petite lengths", coloring: "Burgundy", style: "Modern", practicality: "Grass"},
  items: [
    {role:"dress", description:"Burgundy midi with structured shoulders and elbow sleeves", reason:"Balance pear proportions", estimatedPriceUSD:80},
    {role:"shoes", description:"Burgundy pointed flats", reason:"Grass and no high heels", estimatedPriceUSD:35},
    {role:"bag", description:"Small structured silver bag", reason:"Petite accessory scale", estimatedPriceUSD:20},
  ], silhouette:"Defined high waist, petite midi", palette:["Burgundy", "Silver"],
  stylingDecisions:["Structured shoulder balances pear shape", "Petite midi and scaled bag", "Pointed flats for grass"],
  mustInclude:["Burgundy", "Tailoring"], mustAvoid:["Beige", "High heels", "Sleeveless"],
  coverage:Object.entries({...input.profile,...input.request}).map(([field])=>({field,status:"used",evidence:"Concrete decision for "+field})),
  rationale:"Structured shoulders balance your proportions; the petite midi and small bag keep the scale intentional. Flats work on grass.",
});
const review = () => ({approved:true,needsClarification:false,issues:[],
  checks:[...Object.keys({...input.profile,...input.request}),"personalization","wearability","restrictions","budgetHonesty"]
    .map(field=>({field,passed:true,evidence:"Verified "+field}))});
const visual = () => ({approved:true,issues:[],checks:["restrictions","outfitFidelity","visibleProfile","stylingDecisions"]
  .map(field=>({field,passed:true,evidence:"Visible detail for "+field}))});
function fakeApi(sequence) {
  const calls=[];
  return {calls, fetch: async (url,options) => {
    const body=JSON.parse(options.body);
    calls.push({url,body});
    const value=sequence.shift();
    assert.ok(value,"Unexpected API call");
    return new Response(JSON.stringify(url.endsWith("images/generations") ? value :
      {choices:[{finish_reason:"stop",message:{content:JSON.stringify(value)}}]}),{status:200});
  }};
}
test("all V6 form fields survive normalization, including Unicode and avoids",()=>{
  const data=normalizeInput({version:7,profile:{...input.profile},request:{...input.request,preferences:"Бордо и серебро"}});
  assert.equal(data.profile.size,"XS");assert.equal(data.request.avoid,input.request.avoid);
  assert.equal(data.request.preferences,"Бордо и серебро");
});
test("ignored, duplicated and invented criteria are rejected",()=>{
  const p=plan();p.coverage=p.coverage.filter(v=>v.field!=="size");
  assert.match(validatePlan(p,input).join(),/size/);
  p.coverage=plan().coverage;p.coverage.find(v=>v.field==="avoid").status="not_relevant";
  assert.match(validatePlan(p,input).join(),/avoid/);
  p.coverage=plan().coverage;p.coverage.push(p.coverage[0]);
  assert.match(validatePlan(p,input).join(),/duplicated/);
  const missing={...input,profile:{...input.profile,hairColor:""}};
  assert.match(validatePlan(plan(),missing).join(),/Invented value: hairColor/);
});
test("a rubber-stamp approval without per-field evidence fails",()=>{
  const r=review();r.checks=r.checks.filter(v=>v.field!=="preferences");
  assert.match(validateReview(r,input).join(),/preferences/);
});
test("an approved plan is rendered and visually checked in order",async()=>{
  const api=fakeApi([plan(),review(),{data:[{b64_json:"aGVsbG8="}]},visual()]);
  const result=await createLook(input,{OPENAI_API_KEY:"test"},api.fetch);
  assert.equal(result.status,"complete");assert.equal(api.calls.length,4);
  assert.ok(api.calls[0].body.messages[1].content.includes('"size":"XS"'));
  assert.ok(api.calls[2].body.prompt.includes(input.request.avoid));
  assert.equal(api.calls[3].body.messages[1].content[1].type,"image_url");
  assert.deepEqual(result.profileSnapshot,input.profile);
});
test("failed coverage is repaired before any paid image call",async()=>{
  const bad=plan();bad.coverage=bad.coverage.filter(c=>c.field!=="skinTone");
  const api=fakeApi([bad,plan(),review(),{data:[{b64_json:"aGVsbG8="}]},visual()]);
  assert.equal((await createLook(input,{OPENAI_API_KEY:"test"},api.fetch)).status,"complete");
  assert.ok(api.calls[1].body.messages[1].content.includes("skinTone"));
  assert.equal(api.calls.filter(c=>c.url.endsWith("images/generations")).length,1);
});
test("twice-rejected plan never generates an image",async()=>{
  const no={...review(),approved:false,issues:["High heels violate avoid"]};
  const api=fakeApi([plan(),no,plan(),no]);
  assert.equal((await createLook(input,{OPENAI_API_KEY:"test"},api.fetch)).status,"plan_rejected");
  assert.equal(api.calls.filter(c=>c.url.endsWith("images/generations")).length,0);
});
test("conflicting requirements return clarification without generating an image",async()=>{
  const api=fakeApi([plan(),{...review(),approved:false,needsClarification:true,issues:["Requested heels and prohibited heels"]}]);
  assert.equal((await createLook(input,{OPENAI_API_KEY:"test"},api.fetch)).status,"needs_clarification");
  assert.equal(api.calls.length,2);
});
test("image restriction failure does not return or save a bad image",async()=>{
  const api=fakeApi([plan(),review(),{data:[{b64_json:"aGVsbG8="}]},{...visual(),approved:false,issues:["Sleeveless dress"]}]);
  const result=await createLook(input,{OPENAI_API_KEY:"test"},api.fetch);
  assert.equal(result.status,"image_rejected");assert.equal(result.imageUrl,undefined);
});
test("visual approval without evidence is rejected",async()=>{
  const api=fakeApi([plan(),review(),{data:[{b64_json:"aGVsbG8="}]},{...visual(),checks:[]}]);
  assert.equal((await createLook(input,{OPENAI_API_KEY:"test"},api.fetch)).status,"image_rejected");
});
test("renderer receives concrete item geometry and client restrictions",()=>{
  const prompt=imagePrompt(plan(),input);
  assert.ok(prompt.includes("elbow sleeves"));assert.ok(prompt.includes("No beige"));
  assert.ok(prompt.includes('"heightCategory":"Petite"'));
});
test("old V6 payload and malformed JSON fail explicitly instead of using old image logic",async()=>{
  for (const body of ['{"prompt":"old"}','{broken']) {
    const response=await worker.fetch(new Request("https://example.test",{method:"POST",body}),{OPENAI_API_KEY:"test"});
    assert.equal(response.status,400);
  }
});
test("unexpected upstream failure returns no credentials or profile data",async()=>{
  const response=await worker.fetch(new Request("https://example.test",{method:"POST",body:JSON.stringify({version:7,...input})}),{});
  assert.equal(response.status,503);assert.deepEqual(await response.json(),{error:"WORKER_NOT_CONFIGURED"});
});
