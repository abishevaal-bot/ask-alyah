import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:alyah_style/look_history.dart';
import 'package:alyah_style/pages/my_looks/my_looks_widget.dart';

void main() {
  testWidgets('saved history is listed and deletion requires confirmation',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    await LookHistory.save({
      'id': 'one',
      'status': 'complete',
      'imageUrl':
          'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Wl6EqYAAAAASUVORK5CYII=',
      'createdAt': '2026-09-29T12:00:00Z',
      'plan': {'concept': 'Your burgundy wedding look'},
    });
    await tester.pumpWidget(const MaterialApp(home: MyLooksWidget()));
    await tester.pumpAndSettle();
    expect(find.text('Your burgundy wedding look'), findsOneWidget);
    await tester.tap(find.text('Delete'));
    await tester.pumpAndSettle();
    expect(find.text('Delete this saved look?'), findsOneWidget);
    await tester.tap(find.text('Keep'));
    await tester.pumpAndSettle();
    expect((await LookHistory.load()).length, 1);
    await tester.tap(find.text('Delete'));
    await tester.pumpAndSettle();
    await tester.tap(find.descendant(
        of: find.byType(AlertDialog),
        matching: find.widgetWithText(TextButton, 'Delete')));
    await tester.pumpAndSettle();
    expect(await LookHistory.load(), isEmpty);
    await tester.pumpAndSettle();
    expect(find.text('Your saved looks will appear here.'), findsOneWidget);
  });
}
