import 'dart:convert';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:alyah_style/look_history.dart';
import 'package:alyah_style/client_style_profile.dart';

void main() {
  setUp(() => SharedPreferences.setMockInitialValues({}));
  test(
      'save survives reload, deduplicates and preserves request and profile snapshots',
      () async {
    final profile = ClientStyleProfile.instance;
    profile.size = 'XS';
    profile.styleDirections = ['Modern'];
    final look = <String, dynamic>{
      'id': 'one',
      'version': 7,
      'status': 'complete',
      'imageUrl': 'https://example.test/look.jpg',
      'profileSnapshot': profile.toJson(),
      'requestSnapshot': {'occasion': 'Wedding', 'avoid': 'No high heels'},
      'plan': {'rationale': 'A specific explanation'},
    };
    await LookHistory.save(look);
    profile.size = 'M';
    profile.styleDirections.add('Classic');
    await LookHistory.save(look);
    final loaded = await LookHistory.load();
    expect(loaded.length, 1);
    expect(loaded.first['profileSnapshot']['size'], 'XS');
    expect(loaded.first['profileSnapshot']['styleDirections'], ['Modern']);
    expect(loaded.first['requestSnapshot']['avoid'], 'No high heels');
    await LookHistory.delete('one');
    expect(await LookHistory.load(), isEmpty);
  });
  test('corrupt history is not silently overwritten', () async {
    SharedPreferences.setMockInitialValues({'alyah_looks_v7': '{broken'});
    await expectLater(
        LookHistory.save(
            {'id': 'one', 'status': 'complete', 'imageUrl': 'url'}),
        throwsFormatException);
    expect((await SharedPreferences.getInstance()).getString('alyah_looks_v7'),
        '{broken');
  });
  test('incomplete generation cannot be saved', () async {
    await expectLater(
        LookHistory.save({'id': 'one', 'status': 'image_rejected'}),
        throwsFormatException);
    expect(await LookHistory.load(), isEmpty);
  });
  test('history quota failure keeps existing looks', () async {
    final original = [
      {'id': 'old', 'status': 'complete', 'imageUrl': 'url'}
    ];
    SharedPreferences.setMockInitialValues(
        {'alyah_looks_v7': jsonEncode(original)});
    await expectLater(
        LookHistory.save({
          'id': 'new',
          'status': 'complete',
          'imageUrl': 'x' * (21 * 1024 * 1024)
        }),
        throwsStateError);
    expect((await LookHistory.load()).single['id'], 'old');
  });
}
