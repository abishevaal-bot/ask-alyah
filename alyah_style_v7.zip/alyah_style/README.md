# Ask Alyah V7

See START_V7_RU.md for setup and validation.

Flutter client and Cloudflare Worker must both be upgraded.

Verified with Flutter 3.47.5: release web build, 5 Flutter tests, 12 Worker tests.
Real OpenAI styling outputs and Cloudflare deployment still need to be checked after connection.
