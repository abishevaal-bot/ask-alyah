import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class MyLookWidget extends StatefulWidget {
  const MyLookWidget({
    super.key,
    required this.generatedImage,
    this.occasion,
    this.budget,
    this.preferences,
  });

  final String? generatedImage;
  final String? occasion;
  final String? budget;
  final String? preferences;

  static String routeName = 'MyLook';
  static String routePath = '/myLook';

  @override
  State<MyLookWidget> createState() => _MyLookWidgetState();
}

class _MyLookWidgetState extends State<MyLookWidget> {
  final scaffoldKey = GlobalKey<ScaffoldState>();

  String get _occasion => (widget.occasion?.trim().isNotEmpty ?? false)
      ? widget.occasion!.trim()
      : 'your occasion';

  String get _budget => (widget.budget?.trim().isNotEmpty ?? false)
      ? widget.budget!.trim()
      : 'your selected budget';

  String get _note {
    final pref = widget.preferences?.trim() ?? '';
    final extra = pref.isEmpty ? '' : ' I also incorporated your preference: “$pref”.';
    return 'Alyah created this as one coordinated head-to-toe look for $_occasion, while keeping $_budget in mind.$extra Use the image as your styling blueprint: keep the silhouette, palette, shoes, bag and accessories working together as one outfit.';
  }

  @override
  Widget build(BuildContext context) {
    final image = widget.generatedImage?.trim() ?? '';
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: const Color(0xFFFFFBF5),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 720),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          FlutterFlowIconButton(
                            borderRadius: 8,
                            buttonSize: 40,
                            fillColor: Colors.transparent,
                            icon: Icon(Icons.arrow_back_ios_new_rounded,
                                color: FlutterFlowTheme.of(context).primaryText,
                                size: 20),
                            onPressed: () => context.safePop(),
                          ),
                          Text('ALYAH',
                              style: GoogleFonts.montserrat(
                                  fontSize: 18, fontWeight: FontWeight.w700,
                                  color: FlutterFlowTheme.of(context).primaryText)),
                          const SizedBox(width: 40),
                        ],
                      ),
                      const SizedBox(height: 24),
                      Text('Your Alyah Look',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.playfairDisplay(
                              fontSize: 30, fontWeight: FontWeight.w700,
                              color: FlutterFlowTheme.of(context).primaryText)),
                      const SizedBox(height: 6),
                      Text('A complete AI-styled outfit for $_occasion',
                          textAlign: TextAlign.center,
                          style: GoogleFonts.montserrat(
                              fontSize: 14,
                              color: FlutterFlowTheme.of(context).secondaryText)),
                      const SizedBox(height: 20),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: image.isNotEmpty
                            ? Image.network(
                                image,
                                width: double.infinity,
                                fit: BoxFit.contain,
                                errorBuilder: (_, __, ___) => _imageFallback(context,
                                    'The generated image could not be loaded. Please create the look again.'),
                              )
                            : _imageFallback(context, 'No generated look yet.'),
                      ),
                      const SizedBox(height: 20),
                      Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFFE8DED4)),
                        ),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Icon(Icons.auto_awesome_rounded,
                                color: Color(0xFF7A5C45), size: 24),
                            const SizedBox(width: 14),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text('Stylist Note',
                                      style: GoogleFonts.montserrat(
                                          fontSize: 15, fontWeight: FontWeight.w700,
                                          color: const Color(0xFF7A5C45))),
                                  const SizedBox(height: 8),
                                  Text(_note,
                                      style: GoogleFonts.montserrat(
                                          fontSize: 14, height: 1.5,
                                          color: FlutterFlowTheme.of(context).primaryText)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 20),
                      SizedBox(
                        height: 54,
                        child: FilledButton.icon(
                          onPressed: () => context.goNamed(StyleMeWidget.routeName),
                          style: FilledButton.styleFrom(
                            backgroundColor: const Color(0xFF4A3728),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                          ),
                          icon: const Icon(Icons.auto_fix_high_rounded),
                          label: Text('Create Another Look',
                              style: GoogleFonts.montserrat(fontWeight: FontWeight.w600)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _imageFallback(BuildContext context, String message) => Container(
        constraints: const BoxConstraints(minHeight: 320),
        alignment: Alignment.center,
        color: const Color(0xFFF1ECE7),
        padding: const EdgeInsets.all(24),
        child: Text(message,
            textAlign: TextAlign.center,
            style: GoogleFonts.montserrat(
                color: FlutterFlowTheme.of(context).secondaryText)),
      );
}
