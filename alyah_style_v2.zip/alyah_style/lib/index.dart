// Export pages
export '/pages/welcome/welcome_widget.dart' show WelcomeWidget;
export '/pages/meet_alyah/meet_alyah_widget.dart' show MeetAlyahWidget;
export '/pages/about_you/about_you_widget.dart' show AboutYouWidget;
export '/pages/your_style_goals/your_style_goals_widget.dart'
    show YourStyleGoalsWidget;
export '/pages/discover_me/discover_me_widget.dart' show DiscoverMeWidget;
export '/pages/style_me/style_me_widget.dart' show StyleMeWidget;
export '/pages/my_look/my_look_widget.dart' show MyLookWidget;
