import '/components/button/button_widget.dart';
import '/components/color_swatch/color_swatch_widget.dart';
import '/components/identity_card/identity_card_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'discover_me_widget.dart' show DiscoverMeWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DiscoverMeModel extends FlutterFlowModel<DiscoverMeWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for IdentityCard.
  late IdentityCardModel identityCardModel;
  // Model for ColorSwatch.
  late ColorSwatchModel colorSwatchModel1;
  // Model for ColorSwatch.
  late ColorSwatchModel colorSwatchModel2;
  // Model for ColorSwatch.
  late ColorSwatchModel colorSwatchModel3;
  // Model for ColorSwatch.
  late ColorSwatchModel colorSwatchModel4;
  // Model for Button.
  late ButtonModel buttonModel;

  @override
  void initState(BuildContext context) {
    identityCardModel = createModel(context, () => IdentityCardModel());
    colorSwatchModel1 = createModel(context, () => ColorSwatchModel());
    colorSwatchModel2 = createModel(context, () => ColorSwatchModel());
    colorSwatchModel3 = createModel(context, () => ColorSwatchModel());
    colorSwatchModel4 = createModel(context, () => ColorSwatchModel());
    buttonModel = createModel(context, () => ButtonModel());
  }

  @override
  void dispose() {
    identityCardModel.dispose();
    colorSwatchModel1.dispose();
    colorSwatchModel2.dispose();
    colorSwatchModel3.dispose();
    colorSwatchModel4.dispose();
    buttonModel.dispose();
  }
}
