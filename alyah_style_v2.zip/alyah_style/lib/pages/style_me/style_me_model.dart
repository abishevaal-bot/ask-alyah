import '/backend/api_requests/api_calls.dart';
import '/components/section_header2/section_header2_widget.dart';
import '/components/text_field/text_field_widget.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import 'dart:ui';
import '/index.dart';
import 'style_me_widget.dart' show StyleMeWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class StyleMeModel extends FlutterFlowModel<StyleMeWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController1;
  String? get choiceChipsValue1 =>
      choiceChipsValueController1?.value?.firstOrNull;
  set choiceChipsValue1(String? val) =>
      choiceChipsValueController1?.value = val != null ? [val] : [];
  // Model for SectionHeader.
  late SectionHeader2Model sectionHeaderModel1;
  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController2;
  String? get choiceChipsValue2 =>
      choiceChipsValueController2?.value?.firstOrNull;
  set choiceChipsValue2(String? val) =>
      choiceChipsValueController2?.value = val != null ? [val] : [];
  // Model for SectionHeader.
  late SectionHeader2Model sectionHeaderModel2;
  // Model for TextField.
  late TextFieldModel textFieldModel;
  // Stores action output result for [Backend Call - API (GeneratedAlyahLook)] action in Button widget.
  ApiCallResponse? apiResultdyn;
  // Stores action output result for [Backend Call - API (GeneratedAlyahLook)] action in Container widget.
  ApiCallResponse? generatedLook;

  @override
  void initState(BuildContext context) {
    sectionHeaderModel1 = createModel(context, () => SectionHeader2Model());
    sectionHeaderModel2 = createModel(context, () => SectionHeader2Model());
    textFieldModel = createModel(context, () => TextFieldModel());
  }

  @override
  void dispose() {
    sectionHeaderModel1.dispose();
    sectionHeaderModel2.dispose();
    textFieldModel.dispose();
  }
}
