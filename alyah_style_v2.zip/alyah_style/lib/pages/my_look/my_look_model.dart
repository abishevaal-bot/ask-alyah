import '/backend/backend.dart';
import '/components/button/button_widget.dart';
import '/components/outfit_item/outfit_item_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'my_look_widget.dart' show MyLookWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class MyLookModel extends FlutterFlowModel<MyLookWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for OutfitItem.
  late OutfitItemModel outfitItemModel1;
  // Model for OutfitItem.
  late OutfitItemModel outfitItemModel2;
  // Model for OutfitItem.
  late OutfitItemModel outfitItemModel3;
  // Model for OutfitItem.
  late OutfitItemModel outfitItemModel4;
  // Model for Button.
  late ButtonModel buttonModel1;
  // Model for Button.
  late ButtonModel buttonModel2;

  @override
  void initState(BuildContext context) {
    outfitItemModel1 = createModel(context, () => OutfitItemModel());
    outfitItemModel2 = createModel(context, () => OutfitItemModel());
    outfitItemModel3 = createModel(context, () => OutfitItemModel());
    outfitItemModel4 = createModel(context, () => OutfitItemModel());
    buttonModel1 = createModel(context, () => ButtonModel());
    buttonModel2 = createModel(context, () => ButtonModel());
  }

  @override
  void dispose() {
    outfitItemModel1.dispose();
    outfitItemModel2.dispose();
    outfitItemModel3.dispose();
    outfitItemModel4.dispose();
    buttonModel1.dispose();
    buttonModel2.dispose();
  }
}
