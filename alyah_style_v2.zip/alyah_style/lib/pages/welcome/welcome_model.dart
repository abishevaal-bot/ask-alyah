import '/components/brand_logo/brand_logo_widget.dart';
import '/components/button/button_widget.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/index.dart';
import 'welcome_widget.dart' show WelcomeWidget;
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class WelcomeModel extends FlutterFlowModel<WelcomeWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for BrandLogo.
  late BrandLogoModel brandLogoModel;
  // Model for Button.
  late ButtonModel buttonModel;

  @override
  void initState(BuildContext context) {
    brandLogoModel = createModel(context, () => BrandLogoModel());
    buttonModel = createModel(context, () => ButtonModel());
  }

  @override
  void dispose() {
    brandLogoModel.dispose();
    buttonModel.dispose();
  }
}
