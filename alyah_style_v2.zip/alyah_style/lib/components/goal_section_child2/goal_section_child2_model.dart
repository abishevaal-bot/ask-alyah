import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'goal_section_child2_widget.dart' show GoalSectionChild2Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GoalSectionChild2Model extends FlutterFlowModel<GoalSectionChild2Widget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
