import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'brand_logo_model.dart';
export 'brand_logo_model.dart';

class BrandLogoWidget extends StatefulWidget {
  const BrandLogoWidget({super.key});

  @override
  State<BrandLogoWidget> createState() => _BrandLogoWidgetState();
}

class _BrandLogoWidgetState extends State<BrandLogoWidget> {
  late BrandLogoModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => BrandLogoModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          'ALYAH',
          style: FlutterFlowTheme.of(context).headlineLarge.override(
                font: GoogleFonts.playfairDisplay(
                  fontWeight: FontWeight.w300,
                  fontStyle:
                      FlutterFlowTheme.of(context).headlineLarge.fontStyle,
                ),
                color: FlutterFlowTheme.of(context).primaryText,
                fontSize: 42.0,
                letterSpacing: 0.0,
                fontWeight: FontWeight.w300,
                fontStyle: FlutterFlowTheme.of(context).headlineLarge.fontStyle,
                lineHeight: 1.2,
              ),
        ),
        Container(
          width: 40.0,
          height: 1.0,
          decoration: BoxDecoration(
            color: FlutterFlowTheme.of(context).primary30,
            shape: BoxShape.rectangle,
          ),
        ),
      ].divide(SizedBox(height: 4.0)),
    );
  }
}
