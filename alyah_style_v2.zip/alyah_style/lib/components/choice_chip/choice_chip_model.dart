import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'choice_chip_widget.dart' show ChoiceChipWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ChoiceChipModel extends FlutterFlowModel<ChoiceChipWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
