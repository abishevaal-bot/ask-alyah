import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'goal_section_widget.dart' show GoalSectionWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class GoalSectionModel extends FlutterFlowModel<GoalSectionWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
