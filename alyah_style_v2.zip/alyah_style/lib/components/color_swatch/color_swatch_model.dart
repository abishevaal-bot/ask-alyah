import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'color_swatch_widget.dart' show ColorSwatchWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ColorSwatchModel extends FlutterFlowModel<ColorSwatchWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
