import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBYwp5nZaL-EO34rs438nL0jNeL-3gWdvY",
            authDomain: "alyah-45659.firebaseapp.com",
            projectId: "alyah-45659",
            storageBucket: "alyah-45659.firebasestorage.app",
            messagingSenderId: "469387089694",
            appId: "1:469387089694:web:45852f1bf74a756b11db0f",
            measurementId: "G-4K6VQ5M22K"));
  } else {
    await Firebase.initializeApp();
  }
}
