import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SavedLooksRecord extends FirestoreRecord {
  SavedLooksRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "created_at" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "user_ref" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  void _initializeFields() {
    _createdAt = snapshotData['created_at'] as DateTime?;
    _userRef = snapshotData['user_ref'] as DocumentReference?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('saved_looks');

  static Stream<SavedLooksRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SavedLooksRecord.fromSnapshot(s));

  static Future<SavedLooksRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SavedLooksRecord.fromSnapshot(s));

  static SavedLooksRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SavedLooksRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SavedLooksRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SavedLooksRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SavedLooksRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SavedLooksRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSavedLooksRecordData({
  DateTime? createdAt,
  DocumentReference? userRef,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'created_at': createdAt,
      'user_ref': userRef,
    }.withoutNulls,
  );

  return firestoreData;
}

class SavedLooksRecordDocumentEquality implements Equality<SavedLooksRecord> {
  const SavedLooksRecordDocumentEquality();

  @override
  bool equals(SavedLooksRecord? e1, SavedLooksRecord? e2) {
    return e1?.createdAt == e2?.createdAt && e1?.userRef == e2?.userRef;
  }

  @override
  int hash(SavedLooksRecord? e) =>
      const ListEquality().hash([e?.createdAt, e?.userRef]);

  @override
  bool isValidKey(Object? o) => o is SavedLooksRecord;
}
